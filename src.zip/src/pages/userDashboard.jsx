import React, { useEffect, useState } from 'react';
import './UserDashboard.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const sampleComplaints = [
  { id: 1, category: 'Garbage', status: 'Pending', description: 'Garbage not collected', date: '2024-05-01' },
  { id: 2, category: 'Road', status: 'In Progress', description: 'Pothole on main street', date: '2024-04-28' },
  { id: 3, category: 'Water', status: 'Resolved', description: 'Pipeline leakage fixed', date: '2024-04-25' },
];

const UserDashboards = () => {
  const [complaints, setComplaints] = useState([]);
  const [activePage, setActivePage] = useState("Dashboard");
  const [filterCategory, setFilterCategory] = useState('All');

  useEffect(() => {
    setComplaints(sampleComplaints);
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this complaint?")) {
      setComplaints(prev => prev.filter(c => c.id !== id));
    }
  };

  const filteredComplaints = complaints.filter(c =>
    filterCategory === 'All' || c.category === filterCategory
  );

  const categories = [...new Set(complaints.map(c => c.category))];

  return (
    <div className="d-flex min-vh-100">
      {/* Sidebar */}
      <aside className="bg-primary text-white p-4" style={{ width: '250px' }}>
        <h1 className="mb-5">🌱 Eco Guardian</h1>
        <nav className="nav flex-column">
          {["Dashboard", "My Complaints", "New Complaint", "Settings", "Logout"].map((item) => (
            <button
              key={item}
              className={`btn text-start nav-link text-white ${activePage === item ? 'active-link' : ''}`}
              onClick={() => setActivePage(item)}
            >
              {item}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-grow-1 p-4 bg-light">
        <h2 className="mb-4">{activePage}</h2>

        {activePage === "Dashboard" && (
          <>
            <div className="row g-4 mb-4">
              <div className="col-md-4">
                <div className="card shadow">
                  <div className="card-body d-flex align-items-center">
                    <i className="bi bi-exclamation-circle-fill text-primary fs-3 me-3"></i>
                    <div>
                      <p className="mb-1 text-muted">Total Complaints</p>
                      <h5 className="mb-0">{complaints.length}</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card shadow">
                  <div className="card-body d-flex align-items-center">
                    <i className="bi bi-hourglass-split text-warning fs-3 me-3"></i>
                    <div>
                      <p className="mb-1 text-muted">Pending</p>
                      <h5 className="mb-0">{complaints.filter(c => c.status === 'Pending').length}</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="card shadow">
                  <div className="card-body d-flex align-items-center">
                    <i className="bi bi-check-circle-fill text-success fs-3 me-3"></i>
                    <div>
                      <p className="mb-1 text-muted">Resolved</p>
                      <h5 className="mb-0">{complaints.filter(c => c.status === 'Resolved').length}</h5>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {(activePage === "Dashboard" || activePage === "My Complaints") && (
          <>
            {/* Filters */}
            <div className="filters mb-4 d-flex align-items-center">
              <label className="me-2">Filter by Category:</label>
              <select
                value={filterCategory}
                onChange={e => setFilterCategory(e.target.value)}
                className="form-select w-auto"
              >
                <option value="All">All</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            {/* Complaints Table */}
            <div className="card shadow">
              <div className="card-body">
                <h5 className="card-title mb-3">My Complaints</h5>
                <div className="table-responsive">
                  <table className="table table-striped">
                    <thead className="table-light">
                      <tr>
                        <th>ID</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredComplaints.length === 0 ? (
                        <tr>
                          <td colSpan="6" className="text-center">No complaints found.</td>
                        </tr>
                      ) : (
                        filteredComplaints.map((c) => (
                          <tr key={c.id}>
                            <td>{c.id}</td>
                            <td>{c.category}</td>
                            <td>{c.description}</td>
                            <td>
                              <span className={`badge ${c.status === 'Resolved' ? 'bg-success' : 'bg-warning text-dark'}`}>
                                {c.status}
                              </span>
                            </td>
                            <td>{c.date}</td>
                            <td>
                              <button className="btn btn-sm btn-primary me-2">View</button>
                              <button className="btn btn-sm btn-danger" onClick={() => handleDelete(c.id)}>Delete</button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </>
        )}

        {activePage === "New Complaint" && (
          <div className="alert alert-info">New Complaint Form (Coming Soon)</div>
        )}
        {activePage === "Settings" && (
          <div className="alert alert-info">Settings Page (Coming Soon)</div>
        )}
        {activePage === "Logout" && (
          <div className="alert alert-danger">Logging out... (Demo only)</div>
        )}
      </main>
    </div>
  );
};

export default UserDashboards;