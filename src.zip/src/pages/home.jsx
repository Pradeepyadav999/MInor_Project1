import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <div className="home">
      <header className="hero-section">
        <h1>Welcome to Eco-Guardian</h1>
        <p>Report municipal issues like garbage, pipeline leaks, and potholes. Help keep your city clean and efficient.</p>
        <a href="/report" className="report-button">Report an Issue</a>
      </header>

      <section className="features-section">
        <h2>What You Can Do</h2>
        <div className="features-grid">
          <div className="feature-box">
            <img src="https://source.unsplash.com/300x200/?camera,garbage" alt="Upload" />
            <h3>📸 Upload Photos</h3>
            <p>Capture and submit images of issues like garbage or leaks.</p>
          </div>
          <div className="feature-box">
            <img src="https://source.unsplash.com/300x200/?tracking,map" alt="Track" />
            <h3>📍 Track Complaints</h3>
            <p>Monitor the progress and resolution status of your reports.</p>
          </div>
          <div className="feature-box">
            <img src="https://source.unsplash.com/300x200/?worker,phone" alt="Contact" />
            <h3>📞 Contact Workers</h3>
            <p>Connect directly with assigned authorities and workers.</p>
          </div>
        </div>
      </section>

      <section className="how-it-works">
        <h2>How It Works</h2>
        <div className="steps">
          <div className="step-box">
            <h3>1. Report</h3>
            <p>Click a photo and submit the issue using our easy form.</p>
          </div>
          <div className="step-box">
            <h3>2. Track</h3>
            <p>View live updates on your complaint’s progress and status.</p>
          </div>
          <div className="step-box">
            <h3>3. Resolve</h3>
            <p>Our team collaborates with Nagar Palika to resolve it swiftly.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;