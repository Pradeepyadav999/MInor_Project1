import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaSignInAlt, FaSignOutAlt, FaUser, FaCogs } from 'react-icons/fa'; // Icons for user, admin, login, logout
import './Navbar.css';

// Simulate logged-in user
const user = {_id: "", role: ""}; // Update as per your actual auth logic

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false); // For hamburger menu
  const [dropdownOpen, setDropdownOpen] = useState(false); // For user dropdown menu

  // Toggle dropdown menu
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);
  
  // Logout handler
  const logoutHandler = () => {

    setDropdownOpen(false);
  };

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <>
      {/* Banner Section */}
      <div className="navbar-banner">
        <div className="banner-text">Eco-Guardian - Your Smart Civic Companion</div>
      </div>

      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-brand">
          <Link to="/">Eco-Guardian</Link>
        </div>
        <div className="hamburger" onClick={toggleMenu}>
          ☰
        </div>
        <ul className={`navbar-menu ${isOpen ? 'open' : ''}`}>
          <li><Link to="/report">Report</Link></li>
          <li><Link to="/track">Track</Link></li>
          <li><Link to="/contacts">Contacts</Link></li>
          {/* <li><Link to="/signup">SignUp</Link></li> */}

          {/* Logged-in User Dropdown */}
          {user._id ? (
            <div className="user-dropdown">
              <button onClick={toggleDropdown}>
                <FaUser />
              </button>
              {dropdownOpen && (
                <dialog open>
                  {user.role === 'admin' && (
                    <Link onClick={() => setDropdownOpen(false)} to="/admin/dashboard">
                      <FaCogs /> Admin Dashboard
                    </Link>
                  )}
                  <button onClick={logoutHandler}>
                    <FaSignOutAlt /> Logout
                  </button>
                </dialog>
              )}
            </div>
          ) : (
            <Link to="/login">Login</Link>
          )}
        </ul>
      </nav>
    </>
  );
};

export default Navbar;