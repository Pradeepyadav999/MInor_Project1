import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Navbar from './components/navbar';
import Footer from './components/Footer';
import ProtectedRoute from './components/ProtectedRoute';

import Home from './pages/home';
import PrivacyPolicy from './pages/privacyPolicy'
import Disclaimer from './pages/disclaimer';
import ContactUs from './pages/contactUs';
import ReportIssue from './pages/reportIssue';
import TrackComplaint from './pages/trackComplaint';

import Login from './pages/login';
import Signup from './pages/signUp';

import AdminDashboard from './pages/adminDashboard';

import UserDashboard from './pages/userDashboard';
function App() {

  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
    document.head.appendChild(link);
  }, []);

  // we write above code in .html  file in easy way showm below
  // <link
  //   rel="stylesheet"
  //   href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
  // />

  return (
    <Router>
      <Navbar />
      <div className="container">
        <Routes>


          <Route path="/ " element={<Home />} />
          <Route path="/privacy" element={<PrivacyPolicy />} />
          <Route path="/disclaimer" element={<Disclaimer />} />
          <Route path="/contactUs" element={<ContactUs />} />
          <Route path="/report" element={<ReportIssue />} />
          {/* use it when we wanr protection means without login user cannot report ReportIssue         
            <Route path="/report" element={<ProtectedRoute><ReportIssue /></ProtectedRoute>} /> */}
          <Route path="/track" element={<TrackComplaint />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />

          <Route path="/admin/dashboard" element={<AdminDashboard/>} />

          <Route path="/user/dashboard" element={<UserDashboard/>} />


        </Routes>
      </div>
      <Footer />
    </Router>
  );
}

export default App;
